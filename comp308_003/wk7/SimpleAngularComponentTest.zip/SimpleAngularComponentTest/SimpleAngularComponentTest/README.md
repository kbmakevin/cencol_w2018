﻿# SimpleAngularComponentTest


