﻿import { Component } from '@angular/core';

@Component({
    selector: 'simple-angular-component-test',
    templateUrl: '/app/app.template.html'

    //template: '<h1>Hello from a simple Angular component!</h1>',
    
    
})

//component class
export class AppComponent {
    
}
