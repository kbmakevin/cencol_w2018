﻿// Set the 'development' environment configuration object
module.exports = {
    sessionSecret: 'developmentSessionSecret'

};