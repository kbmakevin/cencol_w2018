﻿import { Routes } from '@angular/router';
import { AboutComponent } from './about.component';

export const AppRoutes: Routes = [
        { path: 'about', component: AboutComponent }

];
