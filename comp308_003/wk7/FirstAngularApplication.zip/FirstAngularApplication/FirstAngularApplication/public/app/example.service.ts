﻿import { Injectable } from '@angular/core';

@Injectable()
export class ExampleService {

    // this is a simple method of the service 
    simpleMethod() {
        return 'Hi, I am a simple service!';
    }

}
