﻿import { Component } from '@angular/core';


@Component({
    selector: 'app-about',
    template: '<h1>About this App</h1>' 
    
    
})

export class AboutComponent {
    //
}
