﻿import { Component } from '@angular/core';
@Component({
    selector: 'sample-component',
    template: '<h1>I am a sample component</h1>'
})

export class SampleComponent {
}