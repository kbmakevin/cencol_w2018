package socket;


public class NetworkClientTest {
	public static void main(String[] args) {
		String host = "localhost";
		if (args.length > 0)
			host = args[0];
		int port = 8088;
		if (args.length > 1)
			port = Integer.parseInt(args[1]);
		NetworkClient nwClient = new NetworkClient(host, port);
		nwClient.connect();
	}
}