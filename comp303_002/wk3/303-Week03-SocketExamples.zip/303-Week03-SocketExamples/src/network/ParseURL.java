package network;


import java.net.URL;

public class ParseURL {
  public static void main(String[] args) throws Exception {
    URL aURL = new URL("https://www.oracle.com/java/index.html");
    System.out.println("protocol = " + aURL.getProtocol());
    System.out.println("host = " + aURL.getHost());
    System.out.println("filename = " + aURL.getFile());
    System.out.println("port = " + aURL.getPort());
    System.out.println("ref = " + aURL.getRef());
  }
}