package network;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class DNSLookup {
  public static void main(String args[]) {
    try {
      InetAddress host;
      if (args.length == 0) {
        host = InetAddress.getLocalHost();
      } else {
        host = InetAddress.getByName(args[0]);
      }
      System.out.println("Host:'" + host.getHostName()
          + "' has address: " + host.getHostAddress());
      byte bytes[] = host.getAddress();
      int fourBytes[] = new int[bytes.length];
      for (int i = 0, n = bytes.length; i < n; i++) {
        fourBytes[i] = bytes[i] & 255;
      }
      System.out.println("\t" + fourBytes[0] + "." + fourBytes[1] + "."
          + fourBytes[2] + "." + fourBytes[3]);
    } catch (UnknownHostException e) {
      e.printStackTrace();
    }
  }
}