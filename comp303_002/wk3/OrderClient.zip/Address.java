

/** 
  * Represents a postal address
  * 
  * Possesses:
  * 1. multiple address lines
  * 2. city
  * 3. postcode/zipcode
  * @version 1.0
  */
public class Address implements java.io.Serializable {
	
  //====================================================
  // Instance variables
  //====================================================	
  
  private String [] address;
  private String city;
  private String postcode;
  
  //====================================================
  // Constructors
  //====================================================
  
 /** Constructs an address object
  * @param addressLines an array of strings representing the multiple lines used for an address, e.g. 
  * <pre>
  * 10 The High Street
  * Newtown
  * Glamorgan
  * </pre>
  * @param city the city or town in which the address is located
  * @param postcode the postcode or zip code of the address
  */
  public Address(String [] address, String city, String postcode) {
  	  this.address = address;   
  	  this.city = city;
  	  this.postcode = postcode;
  }
  
  //====================================================
  // Application methods
  //====================================================
  
  /** Returns a formatted string representation of this object
   * @return a string representation of this object
   */
  public String toString() {
  	  StringBuffer result = new StringBuffer("");
  	  for (int i=0; i<address.length; i++) {
  	  	  result.append("\t");
  	  	  result.append(address[i]);
  	  	  result.append("\n");
  	  }
  	  result.append("\t" + city + "\n");
  	  result.append("\t" + postcode + "\n");
  	  result.append("\n");
  	  return result.toString();
  }
      
}


