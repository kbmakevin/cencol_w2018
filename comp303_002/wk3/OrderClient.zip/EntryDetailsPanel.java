

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.*;
import java.awt.event.*;


/** Implements a panel on the Order Entry details display for 
  * inputting the details of each entry. The inofrmation provided 
  * includes the product, the
  * code the quantity and the price.*/
public class EntryDetailsPanel extends JPanel {

   private NewEntryPanel nep;
   private EntryDetailsList edl;
   private SubmitButtonPanel sbp;
   private OrderEntryModel oem;
   
   public EntryDetailsPanel(Order order, ActionListener handler) {
        super(new BorderLayout());
        
        JLabel title = new JLabel("Order Entry Window");
        title.setFont(new Font("Sans", Font.BOLD, 36));  
        JPanel titlePanel = new JPanel();
        titlePanel.add(title);
        add(titlePanel, BorderLayout.NORTH); 
        
        JPanel p = new JPanel(new GridLayout(2, 1, 10, 10));
  
        oem = new OrderEntryModel();
        nep = new NewEntryPanel(order, oem);
        edl = new EntryDetailsList(oem);
        
        nep.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));  
        p.add(nep);
        p.add(new JScrollPane(edl));
        
        add(p, BorderLayout.CENTER);
        
        sbp = new SubmitButtonPanel(handler);
        add(sbp, BorderLayout.SOUTH);
   }

}

