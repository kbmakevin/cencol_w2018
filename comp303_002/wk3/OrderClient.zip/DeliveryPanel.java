
		
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


/** Implements the panel within the main window that is used to 
  * input the delivery address information*/
public class DeliveryPanel extends Box implements ActionListener{
	private Client client;
	private JTextField name  = new JTextField(10);
   private JTextField line1 = new JTextField(10);
   private JTextField line2 = new JTextField(10);
   private JTextField line3 = new JTextField(10);
   private JTextField city = new JTextField(10);      
   private JTextField postcode = new JTextField(10); 
    
	public DeliveryPanel(Client delivery) {
		super(BoxLayout.Y_AXIS);
		client = delivery;
      
      JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("Delivery name:     "));
      p.add(name);
      add(p);
      
      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("  "));
      add(p);
      
      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("Delivery Address: "));
      add(p);
      
      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("Line1:   "));
      p.add(line1);
      add(p);

      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("Line2:   "));
      p.add(line2);
      add(p);
     
      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("Line3:   "));
      p.add(line3);
      add(p);    
      
      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("City:       "));
      p.add(city);
      add(p); 
      
      p = new JPanel(new FlowLayout(FlowLayout.LEFT));
      p.add(new JLabel("Postcode: "));
      p.add(postcode);
      add(p); 
      
      JButton b = new JButton("Enter");
      b.addActionListener(this);
      p = new JPanel();
      p.add(b);
      add(p);
  }
  
  public void actionPerformed(ActionEvent event) {
  	  client.setName(name.getText());
  	  String [] lines = {line1.getText(), line2.getText(), line3.getText()};
  	  Address address = new Address(lines, city.getText(), postcode.getText());
  	  System.out.println("Setting the deliver address details\n" + name.getText() + "\n" + address);
  	  client.setName(name.getText());
  	  client.setAddress(address);
  }
  
}

