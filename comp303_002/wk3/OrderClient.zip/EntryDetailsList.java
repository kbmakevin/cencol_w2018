
import javax.swing.*;

/** Provides a list of all the enteries currently held in the 
  * order. At present there is no way to remove an entry from an 
  * order*/
public class EntryDetailsList extends JList {
	
	public EntryDetailsList(OrderEntryModel model) {
		setModel(model);
      setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
      setSelectedIndex(0);
      setVisibleRowCount(12);	
	}
	
}


