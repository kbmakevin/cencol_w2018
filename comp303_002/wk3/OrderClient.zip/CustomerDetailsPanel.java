

import javax.swing.*;
import javax.swing.border.BevelBorder;
import java.awt.*;
import java.awt.event.*;


/** Implements the main customer details screen. It contains the 
  * delivery panel and the customer pane asd well as the order 
  * entry buytton panel.
  * It is displayed within the OrderEntryFrame using a card layout.*/
public class CustomerDetailsPanel extends JPanel {

   private CustomerPanel cp;
   private DeliveryPanel dp;
   private OrderEntryButtonPanel oep;
   
   public CustomerDetailsPanel(Customer customer, Client delivery, ActionListener handler) {
        super(new BorderLayout());
        
        JLabel title = new JLabel("Customer Details Window");
        title.setFont(new Font("Sans", Font.BOLD, 36));  
        JPanel titlePanel = new JPanel();
        titlePanel.add(title);
        add(titlePanel, BorderLayout.NORTH); 
        
        JPanel p = new JPanel(new GridLayout(1, 2, 10, 10));
        cp = new CustomerPanel(customer);
        JPanel p1 = new JPanel();
        p1.add(cp);
        p1.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));  
        dp = new DeliveryPanel(delivery);
        JPanel p2 = new JPanel();
        p2.add(dp);
        p2.setBorder(BorderFactory.createBevelBorder(BevelBorder.LOWERED));  
        p.add(p1);
        p.add(p2);
        
        add(p, BorderLayout.CENTER);
        
        oep = new OrderEntryButtonPanel(handler);
        add(oep, BorderLayout.SOUTH);
   }

}

