

/**
 * Represents the generic features of clients of the order entry system
 * such as customers who are buying items and customers to whom items are
 * being delivered.
 */
public class Client {
  private String name; 
  private Address address;
  
  public void setName(String name) {
  	  this.name = name;
  }
  
  public void setAddress(Address addr) {
  	  address = addr;
  }
  
  public String getName() {
  	  return name;
  }
  
  public Address getAddress() {
  	  return address;
  }

}


