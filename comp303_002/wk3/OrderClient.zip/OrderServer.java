

import java.rmi.*;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;

/** 
  * This is a simple RMI based server that implements the 
  * RemoteServer specification. It could have used a database for 
  * storing ordewrs in and it should provide
  * facilities for updating the status of orders and for 
  * maintaining the state of both customers and orders. However, 
  * for this
  * simple example, it merely maintains the orders internally 
  * within an ArrayList.
  * 
  * The OrderServer is started form the command line and can take, 
  * zero, one, two or three parameters.
  * <ul>
  * <li>The first parameter is the name to be used to register the 
  * server with the rmiregistry
  * <li>The second parameter is the host on which the rmiregistry is 
  * running
  * <li>The third parameter is the port number for the rmiregistry
  * </ul>
  * @see OrderEntry
  * @version 1.0*/
public class OrderServer extends UnicastRemoteObject implements RemoteServer {

   //============================================================
   // Class / static variables
   //============================================================
	
	private static int customerCount = 1;
	
   //============================================================
   // Instance variables
   //============================================================
	
   private String name = "OrderEntryServer";
   private String port = "1099";
   private String host = "localhost";
   private ArrayList orders = new ArrayList();
   
   //============================================================
   // Constructors
   //============================================================

  /** 
   * This constrcutor allows an instance of the OrderServer to be 
   * created usign the default values for rmiregistry name, host and 
   * port
   * @exception java.rmi.RemoteException
   */
   public OrderServer() throws RemoteException {
   	super();
   } 
   
  /** This constructor allows an instanc eof the OrderServer to be 
   * created with a name for the rmiregistry. The default values for 
   * the host and 
   * port are used.
   *
   * @param name	rmiregistry name
   */
   public OrderServer(String name) throws RemoteException {
   	this(name, "localhost");	
   }   

  /** This constructor allows an instance of the OrderServer to be 
   * created with a name for the rmiregistry and a specified host. 
   * The default values for 
   * port is used.
   *
   * @param name	rmiregistry name
   * @param host 	host on which the rmiregistry is running
   */
   public OrderServer(String name, String host) throws RemoteException {
   	this(name, host, "1099");
   } 
   
  /** This constructor allows an instance of the OrderServer to be 
   * created with a name for the rmiregistry, a specified host and a 
   * particular port number.
   *
   * @param name	rmiregistry name
   * @param host 	host on which the rmiregistry is running
   * @param port	port number on which the rmiregistry is working
   */
   public OrderServer(String name, String host, String port) throws RemoteException {
   	super();
      setName(name);
      setHost(host);	
      setPort(port);
   }  
   
   //============================================================
   // Get and Set methods
   //============================================================
   
  /** 
   * Used to set the name of the server to be used in the 
   * remiregistry
   * @return String
   */
   public void setName(String name) {
   	this.name = name;
   }
   
  /** 
   * Used to retrieve the name of the server in the rmiregistry
   * @return String
   */
   public String getName() {
   	return name;
   }
   
   /**
    * Sets the port on which the rmiregistry is running
    * @param port the port number for the rmiregistry
    */
   private void setPort(String port) {
   	this.port = port;
   }

  /** 
   * Used to retrieve the port number that the rmiregistry is currently using
   * @return String
   */   
   private String getPort() {
   	return port;
   }

   /**
    * Sets the host on which the rmiregistry is running.
    * <p>
    * <>Note</B>An rmiregistry limitation is that the server and 
    * the rmiregistry must be running on the same machine
    * @param host the host for the rmiregistry
    */   
   private void setHost(String host) {
   	this.host = host;
   }

  /** 
   * Used to retrieve the host on which the the rmiregistry is currently running
   * @return String
   */     
   private String getHost() {
   	return host;
   }
   
   //============================================================
   // Application methods
   //============================================================
   
   /**
    * Used to register the server with an rmiregistry. 
    * Uses the current settings for host, port and server name.
    */
   public void register() {
      try {
        System.out.println("Registering server with rmiregistry");
        Naming.rebind("rmi://" + getHost() + ":"+ getPort() + "/" + getName(), this);
        System.out.println("Server Registered as " + getName());
      } catch (Exception e) {
          e.printStackTrace();	
      }
   }
   
   //============================================================
   // Methods specified by the RemoteServer interface
   //============================================================   
  /** 
   * Generates a (unique to the current server) customer identifier.
   * @param name The name of the customer
	* @param address the address of the customer
	* @return the new customer number
	*/   
	public long createCustomer(String name, Address address) throws RemoteException {
	   Date d = new Date();
	   return d.getTime() + customerCount++;
	    	
   }

  /** 
   * Takes a single order object and registers it in the server
   * @param order an instance of the class Order representing a new order
   */
   public void addOrder(Order order) throws RemoteException {
   	 System.out.println("Adding order " + order);  
       orders.add(order);	  	
   }
   
  /** 
   * Handles an array of order objects. Each one is registered with 
   * the server.
   * @param orders an array of orders, each of which will be added to the server
   */
   public void addOrders(Order [] list) throws RemoteException {
       for (int i=0; i<list.length; i++) {
       	 addOrder(list[i]);
       }	
   }
   
  /** 
   * Given an order number, this method allows a client to find out 
   * what the status of that order currently is.
   * @param orderNumber an order number used to check on the status of an order
   */
   public int orderStatus(long orderNumber) throws RemoteException {
   	 int result = 0;
   	 Iterator it = orders.iterator();
       while (it.hasNext()) {
       	 Order o = (Order)it.next();
       	 if (o.isOrderNumber(orderNumber)) {
       	 	result = o.getStatus();
       	 	break;
       	 }
       }	
       return result;
   }
   
   /** 
    * Application main method. 
    */
   public static void main(String [] args) throws RemoteException{
      OrderServer server = null;
    	if (args.length == 0) {
    	    server = new OrderServer();
    	} else if (args.length == 1) {
    	    server = new OrderServer(args[0]);	
      } else if (args.length == 2) {
      	server = new OrderServer(args[0], args[1]);	
      } else {
      	System.out.println("Usage: java OrderServer <serverName> <host> <port>");
      	System.exit(1);
      }
    	server.register();
   }
}
