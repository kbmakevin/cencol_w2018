
import javax.swing.*;
import java.awt.event.*;

/** Provides a panel containing the Next and Exit buttons on the 
  * main customer details screen*/
public class OrderEntryButtonPanel extends JPanel {
  public OrderEntryButtonPanel(ActionListener handler){ 
     JButton b = new JButton("Next");
     b.addActionListener(handler);
     b.setMnemonic('N');
     b.setToolTipText("Go to the order entry details screen");
     add(b);
     b = new JButton("Exit");
     b.addActionListener(handler);
     b.setMnemonic('x');
     b.setToolTipText("Exit the application");
     add(b);   
       

  }
}






