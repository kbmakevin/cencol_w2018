
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

/** This panel contains the EntryDetailsPanel and the 
  * EntryDetailsList panel. It is used to contain
  * all the display elements for the Entry details screen.*/
public class NewEntryPanel extends JPanel {
	private Order order;
	private JTextField product  = new JTextField(10);
   private JTextField code = new JTextField(10);
   private JTextField quantity = new JTextField(10);
   private JTextField price = new JTextField(10);
   private OrderEntryModel orderEntryModel;
	
	public NewEntryPanel(Order order, OrderEntryModel orderEntryModel) {
	    super(new GridLayout(1, 2, 10, 10));	
	    this.order = order;
	    this.orderEntryModel = orderEntryModel;
	    
	    EntryHandler handler = new EntryHandler();
	    
	    
	    JPanel grid = new JPanel(new GridLayout(5, 2, 5, 5));
	    
	    JLabel label = new JLabel("Enter new Order");
	    label.setFont(new Font("Sans", Font.BOLD, 18));
	    grid.add(label);
	    grid.add(new JLabel(" "));
	    
	    //JPanel p = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    grid.add(new JLabel("Product"));
	    grid.add(product);
	    //add(p);
	    
	    //p = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    grid.add(new JLabel("Code"));
	    grid.add(code);
	    //add(p);
	    
	    //p = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    grid.add(new JLabel("Quantity"));
	    grid.add(quantity);
	    //add(p);
	    
	    //p = new JPanel(new FlowLayout(FlowLayout.LEFT));
	    grid.add(new JLabel("Price"));
	    grid.add(price);
	    //add(p);
	    
	    JPanel p1 = new JPanel();
	    p1.add(grid);
	    add(p1);
	    
	    JButton b = new JButton("Enter Details");
	    b.addActionListener(handler);
	    Box p2 = new Box(BoxLayout.X_AXIS);
	    p2.add(b);
	    add(p2);
	}
	
	class EntryHandler implements ActionListener {
	    public void actionPerformed(ActionEvent event) {
	    	int qty = Integer.parseInt(quantity.getText());
	    	double pr = Double.parseDouble(price.getText());
	    	order.addEntry(product.getText(), code.getText(), qty, pr);
	    	orderEntryModel.addElement(product.getText() + " : " + code.getText() + " : " + qty + " = " + pr);
	    	product.setText("");
	    	code.setText("");
	    	quantity.setText("");
	    	price.setText("");	    	
	    }	
	}
	
}
