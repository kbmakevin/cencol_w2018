

import java.awt.event.*;

/** This class handles the main window button actions, including 
  * exit, next and submit.*/
public class Handler implements ActionListener {
    private OrderEntryFrame frame;
    public Handler(OrderEntryFrame frame) {
        this.frame = frame;
    }
    public void actionPerformed(ActionEvent event) {
    
        String cmd = event.getActionCommand();      
        if (cmd.equalsIgnoreCase("Exit")) {
            frame.close();
        } else if (cmd.equalsIgnoreCase("Next")) {
            frame.next();
        } else if (cmd.equalsIgnoreCase("Submit")) {
        	   frame.submitOrder();
        }
    }

}