
import javax.swing.*;
import java.awt.Container;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.awt.FlowLayout;
import java.awt.CardLayout;
import java.awt.event.*;


/**
 * Provides the main grpahical application window within which the two data entry panels
 * will be displayed. As this is only a test application no data entry verification has been
 * implemented. the display itself is comprised of a number of panels which together form the 
 * user interface structure.
 */
public class OrderEntryFrame extends JFrame {

    private Customer customer = new Customer();
    private Client delivery = new Client();
    private Order order;
    private CardLayout layout;
    private ServerProxy server;
 
    public OrderEntryFrame() {
        super("Order Entry System");
        
        // Set up the link to the server
        server = new ServerProxy();
        
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowHandler());
        
        Container pane = getContentPane();
        layout = new CardLayout();
        pane.setLayout(layout);
        
        JPanel mainPanel = new JPanel(new BorderLayout());
        
        Handler handler = new Handler(this);
        
        // Add the customer details panels
        CustomerDetailsPanel cdp = new CustomerDetailsPanel(customer, delivery, handler);     
        pane.add(cdp, "main panel"); 
        
        // Add the order details panel
        order = new Order();
        EntryDetailsPanel edp = new EntryDetailsPanel(order, handler); 
        pane.add(edp, "entry panel");      
        layout.show(pane, "main panel");
                  
        setLookAndFeel();
      
        pack();
        setVisible(true);
    }
    
    /**
     * The main order submission method. This method marshalls all the information relating to the customer
     * the delivery address and the order together and passes the fully constructed order to the server proxy.
     */
    public void submitOrder() {
    	 order.setName(customer.getName());
    	 order.setAccountNumber(customer.getNumber());
    	 order.setAddress(customer.getAddress());
    	 order.setDeliveryName(delivery.getName());
    	 order.setDeliveryAddress(delivery.getAddress());
    	 server.addOrder(order);
    }
    
    /**
     * Causes the data entry panel to be displayed within the frame
     */
    public void next() {
    	layout.show(getContentPane(), "entry panel");
    }
    
    /**
     * Provides for a controlled exit from the application by displaying a confirmation
     * dialog before exiting.
     */
    public void close() {
    	   // An example of using an JOptionPane
         int response = JOptionPane.showConfirmDialog(this, 
                                                      "Do you wish to exit", 
                                                      "Confirm Exit", 
                                                      JOptionPane.YES_NO_OPTION);
         if (response == JOptionPane.YES_OPTION) {
             System.exit(0);
         }
    }
    
    /**
     * Sets the look and feel to that of the underlying windowing system
     */
    public void setLookAndFeel() {
      try {
       	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
         SwingUtilities.updateComponentTreeUI(this);
      } catch (Exception e) {
      	System.out.println("Warning unknown look and feel");
      }	
   }
    
   //-----------------------------------------------------------------
   // Inner classes
   //-----------------------------------------------------------------
   
   /**
    * Handles the window events on the main window.
    */
   class WindowHandler extends WindowAdapter {  
   	/**
   	 * Called when a user selects the window close option
   	 */
      public void windowClosing(WindowEvent event) {   	
          close();        	
      }	  	
   }
    	 
 
}









