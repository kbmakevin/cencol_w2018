

import javax.swing.*;


/** This class provides a list model for use with the 
  * EntryDetailsList. This is necessary as we need to dynamically 
  * add elements to the list as the user
  * enters new entries to the order. It extends DefaultListModel 
  * and this provides a Vector like protocol.*/
public class OrderEntryModel extends DefaultListModel {

    public void addElement(String s) {
        super.addElement(s);
    }

}

