

/** 
  * Used as a simple class that triggers off the application (i.e. 
  * this is where the main method is stored)
  */
public class Run {

   public static void main(String [] args) {
       new OrderEntryFrame();
   }

}