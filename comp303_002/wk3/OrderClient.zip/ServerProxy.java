
import java.rmi.*;

/**
 * This class provides access to the remote order entry server for the graphical client
 * application. It connects to the remote server object by contacting the rmiregistry on
 * the specified remote host at the specified port and requests a remote server for the
 * given name (by default OrderEntryServer).
 * It then sends all orders it receives to this remote server.
 */

public class ServerProxy {
    
	private String name = "OrderEntryServer";
	private String port = "1099";
	private String host = "localhost";
	private RemoteServer remote;

    /**
      * Constructors for the ServerProxy class
     */	    
	 public ServerProxy() {
		this ("OrderEntryServer");
	 }

  	 public ServerProxy(String s) {
	 	this(s, "1099");
	 }

	 public ServerProxy(String s, String p) {
	 	this(s, p, "localhost");
	 }
	 
	 public ServerProxy(String s, String p, String h) {
	 	name = s;
	 	host = h;
	 	port = p;
	 	connectToServer();
	 }
	 
    /**
      * Connects to the remote server by requesting a remote 
      * reference from the rmiregistry
     */	
	public void connectToServer() {
        try {
      	    System.out.println("Connecting to the server");
			System.out.println("rmi://" + host + ":" + port + "/" + name);

	    remote = (RemoteServer)Naming.lookup
                            ("rmi://" + host + ":" + port + "/" + name);

	    System.out.println("Connection completed");

	} catch (NotBoundException e) {
      	    System.out.println(name + " : Unknown in rmiregistry");
        } catch (Exception e) {
      	    e.printStackTrace();
      }
    }
	
    /**
     * Wraps the remote method call that passes the order object
     * to the remote server. It therefore hides features such as handling 
     * the RemoteException.
     */	
	public void addOrder(Order order) {
	    try {
		System.out.println("Sending order to remote server");
		remote.addOrder(order);
		System.out.println("Order transmission completed");
	    } catch (Exception e) {
		e.printStackTrace();
       	    }
	}
	
}
