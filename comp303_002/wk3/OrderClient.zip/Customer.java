
/**
 * A specialised version of a client that includes a customer account number
 */
public class Customer extends Client {
  private long number;
  
  public void setNumber(long l) {
  	  number = l;
  }
  
  public long getNumber() {
  	  return number;
  }
}


