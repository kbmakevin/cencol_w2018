
import javax.swing.*;
import java.awt.event.*;

/** 
  * Provides a panel containing a centered submit button. A handler 
  * is passed to the constructor for this class to determine what 
  * action should be taken by submitting.*/
public class SubmitButtonPanel extends JPanel {
  public SubmitButtonPanel(ActionListener handler){
  	    JButton b = new JButton("Submit");
  	    b.addActionListener(handler);
  	    add(b);
  }
}




