

import java.rmi.*;

/** A remote interface which specifies the methods published 
 * remotely for an order entry remote server
 * @version 1.0
 */
public interface RemoteServer extends Remote {
	
  /** 
   * Generates a (unique to the current server) customer identifier.
   * @param name The name of the customer
	* @param address the address of the customer
	* @return the new customer number
	* @since 1.0
	*/
	public long createCustomer(String name, Address address) throws RemoteException;
	
  /** 
   * Takes a single order object and registers it in the server
   * @param order an instance of the class Order representing a new order
   */
   public void addOrder(Order order) throws RemoteException;
   
  /** 
   * Handles an array of order objects. Each one is registered with 
   * the server.
   * @param orders an array of orders, each of which will be added to the server
   */
   public void addOrders(Order [] order) throws RemoteException;
   
  /** 
   * Given an order number, this method allows a client to find out 
   * what the status of that order currently is.
   * @param orderNumber an order number used to check on the status of an order
   */
   public int  orderStatus(long orderNumber) throws RemoteException;
   
}
