//package SmartForce.rmi.unit2.topic1;

import java.rmi.*;

/** A simple test client merely intended to check that the 
  * RemoteServer interface and the 
  * OrderServer work correctly*/
public class TestClient {
	 private String name = "OrderEntryServer";
    private String port = "1099";
    private String host = "localhost";
	 
	 public TestClient() {  }
	  
	 public TestClient(String s) {
	 	name = s;
	 }
	 
	 public TestClient(String s, String p) {
	 	name = s;
	 	port = p;
	 }
	 
	 public TestClient(String s, String h, String p) {
	 	name = s;
	 	host = h;
	 	port = p;
	 }
	 
	 public void connectToClient() {
      try {
      	System.out.println("Connecting to the server");
			RemoteServer ref = (RemoteServer)Naming.lookup("rmi://" + host + ":" + port + "/" + name);
			
			System.out.println("Calling method on server: create a customer");
			
			String [] lines = {"24 New Road"};
			Address address = new Address(lines, "Cardiff", "CF5 4JJ");
	      
	      long customerNumber = ref.createCustomer("John Hunt", address);
         
         System.out.println(customerNumber);
         
         System.out.println("Now handle an order");
         // Create an order for an existing account holder with a different delivery name
	      Order order = new Order(customerNumber, "John Hunt", "Denise Cooke");
	      order.setAddress(address);
	      order.setDeliveryAddress("The Grove", "Littleton", "SN14 7JJ");
	      
	      // Now add some entries to the order
	      order.addEntry("Toner Cartridge", "TC1423", 4, 45.00);
	      // order.addEntry("Printer Cable", "PC12", 1, 5.95);
	      order.addEntry("Printer", "PR4500", 1, 256.00);
	      
	      // Print it out for confirmation
	      System.out.println(order);
	      
	      System.out.println("Sending it to the RemoteServer");
	      
	      ref.addOrder(order);
         
      } catch (NotBoundException e) {
      	System.out.println(name + " : Unknown in rmiregistry");
      } catch (Exception e) {
      	e.printStackTrace();
      }
    }
    
    public static void main(String [] args) {
    	TestClient cl;
    	if (args.length == 0) {
    	    cl = new TestClient();
    	} else {
    	    cl = new TestClient(args[0]);	
      }
      cl.connectToClient();
    }
}
