/*
 * Created on 5-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package serialization;

import java.io.*;

public class SaveTest {

	/** 
	* A simple text harness to create an order object and to save it 
	* to a file using serialization
	*/
	public static void main(String [] args){
	
		// Create an order for an existing account holder with 
		//a different delivery name
		Order order = new Order(494812347700L, "John Hunt", "Denise Cooke");
		order.setAddress("2040 Oak Dr", "Boston MA", "02101");
		order.setDeliveryAddress("20 Grove St", "Boston MA", "02163");
		
		// Now add some entries to the order
		order.addEntry("Toner Cartridge", "TC1423", 4, 45.00);
		order.addEntry("Printer Cable", "PC12", 1, 5.95);
		
		// Print it out for confirmation
		System.out.println(order);
		
		System.out.println("Saving order to file temp.ser");
		
		try {
			// Save to file using an ObjectOutputStream
			ObjectOutputStream oos = new ObjectOutputStream
				(new FileOutputStream("temp.ser"));
			oos.writeObject(order);
			oos.close();
			System.out.println("Object save successful");
		} catch (FileNotFoundException exp) {
				System.out.println(
				"File: temp.ser not found when writing to file store");
			} catch (IOException exp) {
				exp.printStackTrace();
		}
	}
}
