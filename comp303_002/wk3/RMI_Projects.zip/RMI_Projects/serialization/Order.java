/*
 * Created on 5-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package serialization;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Date;

/** 
	* Represents an order within an order processing system.
	* 
	* It holds information about the originator of the order.
	* It holds information about the items in the order 
	* (in the form of OrderItems)
	* @see OrderItem
	* @version 1.0*/
public class Order implements java.io.Serializable {
	
	//====================================================
	// Class / static variables
	//====================================================
	private static int orderCount = 1;

	//====================================================
	// Instance variables
	//====================================================	
	
	private long accountNumber; 
	private long orderNumber;  
	private String name;
	private Address address;
	private String deliveryName;
	private Address deliveryAddress;  
	private double total;
	private int status;                                          
	// indicates current status of order 
	// Associated OrderItems held in an ArrayList
	private ArrayList items = new ArrayList();
	
	//====================================================
	// Constructors
	//====================================================  

/** 
	* Creates an order object for a particular account holder
	* @param accountNumber the account holders personal account number
	* @param client the name of the account holder          
	*/
	public Order(long accountNumber, String client){
		setAccountNumber(accountNumber);
		setName(client);
		createOrderNumber();
	}
	
/** 
	* Creates an order object for a particular account holder with a 
	* different deliver address
	* @param accountNumber the account holders personal account number
	* @param client the name of the account holder
	* @param deliveryName the name of the person receiving the delivery
	*/
	public Order(long accountNumber, String client, String deliveryName){
		this(accountNumber, client);
		setDeliveryName(deliveryName);
	}
	
	//====================================================
	// Set and Get methods
	//====================================================  
	
	/**
	* Obtains the current orders unqiue order number
	* @return the order number
	*/
	public long getOrderNumber() {
		return orderNumber;
	}
	
	/** 
	* Sets the name of the person making this order
	* @param name the name of the account holder making the order
	*/
	public void setName(String name) {
		this.name = name;
	}
	
	/** 
	* Sets the address of the person making the order
	* @param addressLine the first line of an address
	* @param city the city of two within which the address is located
	* @param postcode the postcode or zipcode of the address
	*/
	public void setAddress(String addressLine, String city, String postcode){
		String [] lines = {addressLine};
		setAddress(lines, city, postcode);
	}
	
	/** 
	* Sets the address of the person making the order
	* @param addressLine1 the first line of an address
	* @param addressLine2 the second line of an address
	* @param city the city of two within which the address is located
	* @param postcode the postcode or zipcode of the address
	*/
	public void setAddress(String addressLine1, String addressLine2, String city, String postcode){
		String [] lines = {addressLine1, addressLine2};
		setAddress(lines, city, postcode);
	}
	
	/** 
	* Sets the address of the person making the order
	* @param addressLines the lines of an address
	* @param city the city of two within which the address is located
	* @param postcode the postcode or zipcode of the address
	*/
	public void setAddress(String [] addressLines, String city, String postcode){
		address = new Address(addressLines, city, postcode);
	}
	
	/** 
	* Sets the name of the person to receive the items ordered
	* @param name the person to receive the ordered items
	*/
	public void setDeliveryName(String name){
		deliveryName = name;
	}

	/** 
	* Sets the address of the person receiving the order
	* @param addressLine the first line of an address
	* @param city the city of two within which the address is located
	* @param postcode the postcode or zipcode of the address
	*/
	public void setDeliveryAddress(String addressLine1, String city, String postcode){
		String [] lines = {addressLine1};
		setDeliveryAddress(lines, city, postcode);
	}
	
	/** 
	* Sets the address of the person receiving the order
	* @param addressLine1 the first line of an address
	* @param addressLine2 the second line of an address
	* @param city the city of two within which the address is located
	* @param postcode the postcode or zipcode of the address
	*/
	public void setDeliveryAddress(String addressLine1, String addressLine2, String city, String postcode){
		String [] lines = {addressLine1, addressLine2};
		setDeliveryAddress(lines, city, postcode);
	}
	
	/** 
	* Sets the address of the person receiving the order
	* @param addressLines the lines of an address
	* @param city the city of two within which the address is located
	* @param postcode the postcode or zipcode of the address
	*/
	public void setDeliveryAddress(String [] addressLines, String city, String postcode){
		deliveryAddress = new Address(addressLines, city, postcode);
	}
	
	/** 
	* Sets the account number of the person making the order
	* @param accountNumber the account number (e.g. 494867231200)
	*/
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	
	/**
	* Returns the status of the order. At present only a test feature 
	* and will thus always 
	* return zero.
	* @return an int indicating status of the order
	*/
	public int getStatus() {
		return status;
	}

	//====================================================
	// Application methods
	//====================================================
	
	/** 
	* Adds a new entry to the order
	* @param name the name of the product
	* @param codeNumber the code number ofthe product
	* @param quantity the quantity to be ordered
	* @param price the unit proce of the product
	*/
	public void addEntry(String name, String codeNumber, int quantity, double price) {
		OrderEntry entry = new OrderEntry(name, codeNumber, quantity, price);
		total += entry.getCost();
		items.add(entry);
	}

	/**
	* Creates a new order (unique) number
	*/
	private void createOrderNumber() {
		Date d = new Date();
		orderNumber = d.getTime() + orderCount;
		orderCount++;
	}
	
	/**
	* Obtains the current total cost of the order
	* @return the value of the order
	*/
	public double getOrderTotal() {
		  return total;
	}
	
	/**
	* Check to see if the order number matches that passed to this method
	* @returns true if numbers are the same, otherwise false
	*/
	public boolean isOrderNumber(long number) {
		return (number == orderNumber);
	}
	
	/** Returns a formatted string representation of this object
	* @return a string representation of this object
	*/
	public String toString() {
		StringBuffer result = new StringBuffer("\n");
		result.append("Customer Name: " + name + "\n");
		result.append("Customer Address: \n" + address);
		result.append("Account number: " + accountNumber + " \n");
		if (deliveryName != null) {
			result.append("Delivery Name: " + deliveryName + "\n");
		}
		if (deliveryAddress != null) {
			result.append("Delivery Address: \n" + deliveryAddress);
		}
		
		result.append("\n\n");
		
		Iterator it = items.iterator();
		while (it.hasNext()) {
			result.append(it.next());
			result.append("\n");
		}
		
		result.append("\n============\t===========\n");
		result.append("Order Total:\t" + getOrderTotal() + "\n");
		
		return result.toString();
	}
	
}

