/*
 * Created on 5-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package serialization;

import java.io.*;

public class LoadTest {
	
	/** 
	* A minimal test harness to reload a previously saved serialized 
	* instance of the class Order and print out its contents
	*/
	public static void main(String [] args){
		try {
		// Open an object stream to the file
		ObjectInputStream ois = new ObjectInputStream(new FileInputStream("temp.ser"));
		Order order = (Order)ois.readObject();
		
		System.out.println("Reloaded order object");
		System.out.println(order);
		
		} catch (FileNotFoundException exp) {
			System.out.println(
				"File: temp.ser not"+ 
				"found in the current directory");
		} catch (IOException exp) {
			exp.printStackTrace();
		} catch (ClassNotFoundException exp) {
			System.out.println(
				"Can't find definition for class Order");
		}
	}
}