/*
 * Created on 5-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package serialization;

/** Represents a single item within an order.
* 
* The information held represents the:
* name of the item (e.g. Toner Cartridge
* code number of item (e.g. tc1432)
* the qqntity order (e.g. 4)
* the unit price (45.00)
* the total price (180.00)
*
* @version 1.0*/

public class OrderEntry implements java.io.Serializable {

//====================================================
// Instance variables
//====================================================	

private String name; 
private String code;
private int quantity;
private double price;
private double total;

//====================================================
// Constructors
//====================================================

/** 
* Creates a new order item for the specified product 
* for the given quantity
* @param name the name of the product
* @param codeNumber the code number ofthe product
* @param quantity the quantity to be ordered
* @param price the unit proce of the product
*/
public OrderEntry(String name, String codeNumber, int quantity, double price){ 
	setName(name);
	setCodeNumber(codeNumber);
	setQuantity(quantity);
	setPrice(price);
}

//====================================================
// Set and Get methods
//====================================================

/** 
* Sets the price of the item to be ordered and recalcuates the 
* total value of this order item.
* @param price the price of the item being ordered
*/
public void setPrice(double price){    
	this.price = price;
	calculateTotalCost();
}
/** 
* Sets the name of the product represrnted by this order item
* @param name the name of the product being ordered
*/
public void setName(String name){
	this.name = name;
}          
/** 
* Sets the product code number of the item being ordered
* @param code the code of the product being ordered
*/   
	public void setCodeNumber(String code){
	this.code = code;
}   
/** 
* Sets the number of items being ordered
* @param quantity the quantity of the product to be ordered
*/ 
public void setQuantity(int quantity){
	this.quantity = quantity;
	calculateTotalCost();
}

/**
* Returns the current value of this order entry  
* @return the current value of this order entry
*/ 
public double getCost() {
	return total;
}

//====================================================
// Application methods
//====================================================

/**
* Calcuates the current value of this order entry
*/
private void calculateTotalCost() {
	total = quantity * price;
}

/** Returns a formatted string representation of this object
* @return a string representation of this object
*/
public String toString() {
	StringBuffer result = new StringBuffer("");
	result.append("name: " + name);
	result.append("\tcode: " + code);
	result.append("\tquantity: " + quantity);
	result.append("\tprice: " + price);
	result.append("   = " + total);
	return result.toString();
}
}
