/*
 * Created on 3-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package simple;

import java.rmi.*; 

public interface HelloInterface extends java.rmi.Remote { 
 public String query (String request) throws java.rmi.
   RemoteException; 
}

