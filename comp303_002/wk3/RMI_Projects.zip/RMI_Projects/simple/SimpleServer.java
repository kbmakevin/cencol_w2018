/*
 * Created on 3-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package simple;

import java.rmi.*; 
import java.rmi.server.UnicastRemoteObject; 
public class SimpleServer extends UnicastRemoteObject 
                          implements HelloInterface { 
  public SimpleServer() throws RemoteException { 
     super(); 
   try{ 
     System.out.println("Registering server with"+ 
         " rmiregistry"); 
     Naming.rebind("rmi://localhost:1099/Hello", this); 
     System.out.println("Server registered and ready"); 
   } catch (Exception e) { 
   } 
  } 
  public String query(String s) { 
     System.out.println("Query method called"); 
     return s + " Remote World"; 
  }
  public static void main(String [] args) 
  throws RemoteException{ 
  new SimpleServer(); 
 } 
}

  

