/*
 * Created on 3-Jul-2007
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package simple;

import java.rmi.*;

public class SimpleClient {

	public SimpleClient() {
		try {
			System.out.println("Connecting to the SimpleServer");
			HelloInterface ref = (HelloInterface) Naming
					.lookup("rmi://localhost/Hello");
			System.out.println("Calling method on server");
			String reply = ref.query("Hello");
			System.out.println("Result of call is: " + "\n\t" + reply);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		new SimpleClient();
	}
}