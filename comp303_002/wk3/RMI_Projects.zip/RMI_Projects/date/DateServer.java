
package date;

//An elementary example of RMI (Remote Method Invocation): Step 1.
//This program defines the remote interface, so that the object
//can have a remote behavior.  This is done by extending the
//Remote class.

import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Date;

public interface DateServer extends Remote {
	public Date getDate() throws RemoteException;
}