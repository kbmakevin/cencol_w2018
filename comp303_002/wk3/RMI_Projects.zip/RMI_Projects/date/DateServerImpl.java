package date;

//An elementary example of RMI (Remote Method Invocation): Step 2.
//This program implements the remote object interface.
//After compiling, javac DateServerImpl.java, run (Step 3) the rmic tool: 
// rmic DateServerImpl
//It will produce two files:
//- stub DateServerImpl_Stub for the client
//- skeleton DateServerImpl_Skel for the server.

import java.rmi.server.UnicastRemoteObject;
//OR import java.rmi.server.UnicastRemoteServer;
import java.rmi.RMISecurityManager;
//OR import java.rmi.server.StubSecurityManager;
import java.rmi.RemoteException;
import java.rmi.Naming;
import java.util.Date;

public class DateServerImpl extends UnicastRemoteObject implements DateServer {
	public DateServerImpl() throws RemoteException {

	}

	public Date getDate() {
		return new Date();
	}

	public static void main(String args[]) throws Exception {
		//System.setSecurityManager(new RMISecurityManager());
		DateServerImpl dateS = new DateServerImpl();
		Naming.bind("DateServer", dateS);
	}
}