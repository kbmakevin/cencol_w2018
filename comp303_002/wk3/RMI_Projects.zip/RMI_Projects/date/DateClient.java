package date;

//An elementary example of RMI (Remote Method Invocation): Step 6.
//This is the client which requests a date from the DateServer.

import java.rmi.RMISecurityManager;
import java.rmi.Naming;
import java.util.Date;

public class DateClient {
	public static void main(String args[]) throws Exception {
		if (args.length != 1)
			throw new RuntimeException("Syntax: DateClient <hostname>");

		//System.setSecurityManager(new RMISecurityManager());

		DateServer dateServer = (DateServer) Naming.lookup("rmi://" + args[0]
				+ "/DateServer");

		Date when = dateServer.getDate();

		System.out.println(when);
	}
}

