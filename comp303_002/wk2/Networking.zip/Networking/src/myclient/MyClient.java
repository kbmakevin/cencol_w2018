package myclient;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class MyClient {
	static final int DEFAULT_PORT = 12345;

	// static final String hostIP = �10.28.39.18�;
	public static void main(String[] args) {
		try {
			int port = DEFAULT_PORT;
			// optionally specify port as command-line argument
			if (args.length > 0) {
				port = Integer.parseInt(args[0]);
			}
			// InetAddress host = InetAddress.getByName(hostIP);
			InetAddress host = InetAddress.getLocalHost();
			// optionally specify host name as command-line argument
			if (args.length > 1) {
				host = InetAddress.getByName(args[1]);
			}
			Socket socket = new Socket(host, port);
			System.out.println("Demo client running");
			// Create PrintWriter: 2nd arg = true to autoflush buffer
			PrintWriter socketOut = new PrintWriter(socket.getOutputStream(), true);
			socketOut.println("request for the server side");
			// read response from server
			BufferedReader socketIn = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String response = socketIn.readLine();
			// use response
			System.out.println(response);

		} catch (UnknownHostException uhx) {
			uhx.printStackTrace();
		} catch (IOException iox) {
			iox.printStackTrace();
		}
	}
}