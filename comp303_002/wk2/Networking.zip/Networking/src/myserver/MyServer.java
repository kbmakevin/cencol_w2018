package myserver;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class MyServer {
	private static int port;
	static final int DEFAULT_PORT = 12345;

	public static void main(String[] args) {
		int port = DEFAULT_PORT;
		if (args.length > 0) {
			port = Integer.parseInt(args[0]);
		}
		// create a server socket bound to port
		ServerSocket ss = null;
		try {
			ss = new ServerSocket(port);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Demo server running");
		// process one request and respond
		try {
			// listen for TCP/IP connection from client on port
			Socket socket = ss.accept();
			BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
			String str = in.readLine();
			// send response back to client
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			String result = "response back to client";
			// echo result to server-side console
			out.println("The result is " + result);
			socket.close();
		} catch (IOException iox) {
			iox.printStackTrace();
		}
	}
}
