package myserver;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MultithreadedServer {
	private static final int DEFAULT_PORT = 12345;

	public static void main(String[] args) {
		int port = DEFAULT_PORT;
		if (args.length > 0)
			port = Integer.parseInt(args[0]);
		try {
			ServerSocket listener = new ServerSocket(port);
			Socket socket;
			while (true) {
				socket = listener.accept();
				MyServerThread aServer = new MyServerThread(socket);
				Thread t = new Thread(aServer);
				t.start();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
}