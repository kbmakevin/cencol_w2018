package examples;

import java.net.*;
import java.io.*;

/** A starting point for network clients. */
public class NetworkClient {
	protected String host;

	protected int port;

	public NetworkClient(String host, int port) {
		this.host = host;
		this.port = port;
	}

	public String getHost() {
		return (host);
	}

	public int getPort() {
		return (port);
	}

	/**
	 * Establishes the connection, then passes the socket to handleConnection.
	 */
	public void connect() {
		try {
			Socket client = new Socket(host, port);
			handleConnection(client);
		} catch (UnknownHostException uhe) {
			System.out.println("Unknown host: " + host);
			uhe.printStackTrace();
		} catch (IOException ioe) {
			System.out.println("IOException: " + ioe);
			ioe.printStackTrace();
		}
	}

	/**
	 * This is the method you will override when making a network client for
	 * your task. This default version sends a single line ("Generic Network
	 * Client") to the server, reads one line of response, prints it, then
	 * exits.
	 */
	protected void handleConnection(Socket client) throws IOException {
		PrintWriter out = SocketUtil.getPrintWriter(client);
		BufferedReader in = SocketUtil.getBufferedReader(client);
		out.println("Generic Network Client");
		System.out.println("Generic Network Client:\n" + "Made connection to "
				+ host + " and got '" + in.readLine() + "' in response");
		client.close();
	}
}