package examples;

import java.io.*;
import java.net.*;

public class NetworkServer {
	protected int port, maxConnections;

	/**
	 * Build a server on specified port. It will continue to accept connections
	 * (passing each to handleConnection) until an explicit exit command is sent
	 * (e.g. System.exit) or the maximum number of connections is reached.
	 * Specify 0 for maxConnections if you want the server to run indefinitely.
	 */
	public NetworkServer(int port, int maxConnections) {
		this.port = port;
		this.maxConnections = maxConnections;
	}

	/**
	 * Monitor a port for connections. Each time one is established, pass
	 * resulting Socket to handleConnection.
	 */
	public void listen() {
		int i = 0;
		try {
			ServerSocket listener = new ServerSocket(port);
			Socket server;
			while ((i++ < maxConnections) || (maxConnections == 0)) {
				server = listener.accept();
				handleConnection(server);
			}
		} catch (IOException ioe) {
			System.out.println("IOException: " + ioe);
			ioe.printStackTrace();
		}
	}

	protected void handleConnection(Socket server) throws IOException {
		BufferedReader in = SocketUtil.getBufferedReader(server);
		PrintWriter out = SocketUtil.getPrintWriter(server);
		System.out.println("Generic Network Server:\n" + "got connection from "
				+ server.getInetAddress().getHostName() + "\n"
				+ "with first line '" + in.readLine() + "'");
		out.println("Generic Network Server");
		server.close();
	}
}