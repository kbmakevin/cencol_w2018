package examples;

public class NetworkServerTest {
	public static void main(String[] args) {
		int port = 8080;
		if (args.length > 0) {
			port = Integer.parseInt(args[0]);
		}
		NetworkServer server = new NetworkServer(port, 1);
		server.listen();
	}
}