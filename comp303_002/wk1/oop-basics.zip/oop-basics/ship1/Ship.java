package ship1;
// Create a class with five instance variables (fields):
// x, y, speed, direction, and name.
// From the MOST basic OOP section of Java tutorial at coreservlets.com.

public class Ship {
  public double x, y, speed, direction;
  public String name;
}