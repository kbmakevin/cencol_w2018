package people;

public class Person3Test {
  public static void main(String[] args) {
    Person3 p = new Person3("Larry", "Page");
    // doSomethingWith(p);
    System.out.println("Person's full name: " +
                       p.getFullName());
  }
}
