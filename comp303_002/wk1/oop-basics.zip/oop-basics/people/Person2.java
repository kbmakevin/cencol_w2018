package people;

public class Person2 {
  public String firstName, lastName;
  
  public String getFullName() {
    return(firstName + " " + lastName);
  }
}
