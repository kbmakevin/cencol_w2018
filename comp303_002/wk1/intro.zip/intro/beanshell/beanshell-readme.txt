To run beanshell:
 - Double-click the .jar file
 - Go to File menu and select "Capture System in/out/err"
 - Enter Java commands and see the results
   (Define variables, define methods, call methods)
   
 For more info and updated versions:
  - http://www.beanshell.org/
  
  From Java tutorial at 
  http://courses.coreservlets.com/Course-Materials/java.html