package mypackage;

public class PrintVariables {
  public static void main(String[] args) {
    int num1 = 1;
    System.out.println("First number is " + num1);
    double num2 = 2.34;
    System.out.println("Second number is " + num2);
    String message = "Hi";
    System.out.println("Message is " + message);
  }

}
